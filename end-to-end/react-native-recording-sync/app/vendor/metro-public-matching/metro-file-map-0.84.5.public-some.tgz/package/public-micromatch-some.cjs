'use strict';
// MIT source: micromatch 4.0.8; literal .some implementation, same picomatch 2.3.2.
const picomatch = require('picomatch');
const micromatch = {};
micromatch.some = (list, patterns, options) => {
  let items = [].concat(list);

  for (let pattern of [].concat(patterns)) {
    let isMatch = picomatch(String(pattern), options);
    if (items.some(item => isMatch(item))) {
      return true;
    }
  }
  return false;
};
module.exports = micromatch;
