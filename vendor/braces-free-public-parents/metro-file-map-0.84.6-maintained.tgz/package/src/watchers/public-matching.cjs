'use strict';
// MIT: exact public Micromatch 4.0.8 consumer algorithms; see MICROMATCH-LICENSE.
const picomatch = require('picomatch');
const some = (list, patterns, options) => {
  let items = [].concat(list);

  for (let pattern of [].concat(patterns)) {
    let isMatch = picomatch(String(pattern), options);
    if (items.some(item => isMatch(item))) {
      return true;
    }
  }
  return false;
};

module.exports = { some, matcher: (pattern, options) => picomatch(pattern, options) };
